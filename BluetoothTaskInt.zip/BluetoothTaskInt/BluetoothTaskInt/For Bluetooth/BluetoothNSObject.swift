//
//  Bluetooth.swift
//  BluetoothTask
//
//  Created by ToqSoft on 09/05/24.
//

import Foundation
import CoreBluetooth
import UIKit

protocol BluetoothManagerDelegate: AnyObject {
    func didDiscoverPeripheral(_ peripheral: CBPeripheral)
}
private func showAlert(message: String) {
       let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
       alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
       UIApplication.shared.windows.first?.rootViewController?.present(alertController, animated: true, completion: nil)
   }
class BluetoothNSObject: NSObject {
    
    weak var delegate: BluetoothManagerDelegate?
    private var centralManager: CBCentralManager!
    private var discoveredDevices: [CBPeripheral] = []
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    func startScanning() {
        centralManager.scanForPeripherals(withServices: nil, options: nil)
    }
}

extension BluetoothNSObject: CBCentralManagerDelegate {
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            startScanning()
        } else {
            // Handle Bluetooth not available
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any], rssi RSSI: NSNumber) {
        discoveredDevices.append(peripheral)
        delegate?.didDiscoverPeripheral(peripheral)
        
    }
//        switch central.state {
//        case .poweredOn:
//            // Bluetooth is powered on, you can start scanning for peripherals
//            startScanning()
//        case .poweredOff:
//           
//            print("Bluetooth is powered off")
//            showAlert(message: "Bluetooth is powered off")
//        case .resetting:
//            
//            print("Bluetooth is resetting")
//        case .unauthorized:
//
//            print("Unauthorized to use Bluetooth")
//        case .unknown:
//            print("Bluetooth state is unknown")
//        case .unsupported:
//            
//            print("Bluetooth is not supported")
//            showAlert(message: "Bluetooth is not supported")
//        @unknown default:
//            // Handle any future Bluetooth states
//            print("Unknown Bluetooth state")
//        }
//    }
}
