//
//  DeviceListViewModel.swift
//  BluetoothTask
//
//  Created by ToqSoft on 09/05/24.
//
import Foundation
import CoreBluetooth

protocol DeviceListViewModelDelegate: AnyObject {
    func didUpdateDeviceList()
}

class DeviceListViewModel {
    
    var discoveredDevices: [CBPeripheral] = []
    private var bluetoothManager: BluetoothNSObject!
    weak var delegate: DeviceListViewModelDelegate?
    
    init() {
        bluetoothManager = BluetoothNSObject()
        bluetoothManager.delegate = self
    }
    
    func startScanning() {
        bluetoothManager.startScanning()
    }
    
    func connectToDevice(at index: Int) {
        // Implement connection logic
    }
}

extension DeviceListViewModel: BluetoothManagerDelegate {
    func didDiscoverPeripheral(_ peripheral: CBPeripheral) {
        discoveredDevices.append(peripheral)
        delegate?.didUpdateDeviceList()
    }
}
