

import UIKit
import CoreBluetooth

class ViewController: UIViewController,ReloadData {
    
    
    
    @IBOutlet weak var bluetoothtableView: UITableView!
    @IBOutlet weak var forSalesTableView: UITableView!
    private var viewModel: DeviceListViewModel!
    var discountData = DiscountViewModelsales()
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = DeviceListViewModel()
        viewModel.delegate = self
        viewModel.startScanning()
        forSalesTableView.register(UINib(nibName: "salesTableViewCell", bundle: .main), forCellReuseIdentifier: "salesTableViewCell")
        reload()
        didUpdateData()
        getDiscountDirectData()
    }
    
    func reload() {
        DispatchQueue.main.async {
            self.forSalesTableView.reloadData()
        }
        
    }
    
    func didUpdateData() {
        discountData.loadData(from: DiscounttypeURL)
        discountData.reloadDelegate = self
    }
    func getDiscountDirectData() {
        discountData.loadData(from: DiscounttypeURL)
    }
}
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == bluetoothtableView{
            return viewModel.discoveredDevices.count
        }else if tableView == forSalesTableView {
            return discountData.filterDataArray.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == bluetoothtableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "bluetoothcell", for: indexPath)
            let device = viewModel.discoveredDevices[indexPath.row]
            
            if let deviceName = device.name, !deviceName.isEmpty {
                cell.textLabel?.text = deviceName
                cell.textLabel?.backgroundColor = UIColor.green
            } else {
                cell.textLabel?.text = "No Name For This Bluetooth"
            }
            
            return cell
        }else if tableView == forSalesTableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "salesTableViewCell", for: indexPath) as!  salesTableViewCell
            cell.passDiscountData = discountData.filterDataArray[indexPath.row]
            cell.getDataToProperties()
            return cell
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewModel.connectToDevice(at: indexPath.row)
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if tableView == bluetoothtableView {
            return "Bluetooth Names"
        }
        return nil
    }
}

extension ViewController: DeviceListViewModelDelegate {
    func didUpdateDeviceList() {
        bluetoothtableView.reloadData()
    }
}


