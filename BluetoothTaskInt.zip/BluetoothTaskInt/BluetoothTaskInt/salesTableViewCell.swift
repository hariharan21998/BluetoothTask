//
//  salesTableViewCell.swift
//  BluetoothTaskInt
//
//  Created by ToqSoft on 09/05/24.
//

import UIKit

class salesTableViewCell: UITableViewCell {
    @IBOutlet weak var rowIDLabel: UILabel!
    @IBOutlet weak var DescribtionLabel: UILabel!
    @IBOutlet weak var discountLabel: UILabel!
    var passDiscountData : DiscountModel?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    func getDataToProperties() {
        rowIDLabel.text = passDiscountData?.rowid.description
        discountLabel.text = passDiscountData?.discount.description
        DescribtionLabel.text = passDiscountData?.description
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
