//
//  DataViewModel.swift
//  BluetoothTaskInt
//
//  Created by ToqSoft on 09/05/24.
//

import Foundation
protocol ReloadData: AnyObject {
    func reload()
    func didUpdateData()
}

protocol DataRepository {
    associatedtype T: Codable & Decodable
    func loadData(from url: String)
}


class DataViewModel<T: Codable>: DataRepository {
    weak var reloadDelegate: ReloadData?
    var updateLoadingStatus: (() -> Void)?
    var dataArray: [T] = [] as! [T] {
        didSet {
            filterDataArray = dataArray
            reloadDelegate?.reload()
        }
    }
    
    var filterDataArray: [T] = [] {
        didSet {
            reloadDelegate?.reload()
        }
    }
    
    func loadData(from url: String) {
        print("URL--->",url)
        JsonDataHelper.fetchData(from: url, modelType: T.self) { result in
            switch result {
            case .success(let fetchedData):
                // Assign fetchedData to dataArray
                self.dataArray = fetchedData
            case .failure(let error):
                // Handle error
                print("Error loading data: \(error.localizedDescription)")
            }
        }
    }
}
