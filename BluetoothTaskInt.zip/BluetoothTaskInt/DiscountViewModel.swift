//
//  DiscountViewModel.swift
//  BluetoothTaskInt
//
//  Created by ToqSoft on 09/05/24.
//

import Foundation
class DiscountViewModelsales : DataViewModel<DiscountModel> {
    
}
