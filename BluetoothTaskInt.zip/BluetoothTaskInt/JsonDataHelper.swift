//
//  JsonDataHelper.swift
//  BluetoothTaskInt
//
//  Created by ToqSoft on 09/05/24.
//

import Foundation
enum DataError : Error{
    case invalidURL
    case invalidResponse
    case invalidData
    case network(Error?)
    case invalidStatusCode(Int)
}
class JsonDataHelper {
    static func fetchData<T: Decodable>(from url: String, modelType: T.Type, completion: @escaping (Result<[T], Error>) -> Void) {
        guard let url = URL(string: url) else {
            completion(.failure(DataError.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(DataError.invalidResponse))
                }
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode([T].self, from: data)
                completion(.success(decodedData))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
}
