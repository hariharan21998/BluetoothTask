//
//  SupplierModel.swift
//  BluetoothTaskInt
//
//  Created by ToqSoft on 09/05/24.
//

import Foundation
let BaseURL = "https://apinatco.azurewebsites.net/api/"
let DiscounttypeURL = BaseURL + "Discounttype?customQuery="

struct DiscountModel : Codable{
    let id: String
    let partitionKey: String
    let rowid: Int
    let createdDate: String?
    let createdBy: String?
    let name: String
    let discount: Double
    let description: String
    let disabled: Bool
    init(id: String, partitionKey: String, rowid: Int, createdDate: String, createdBy: String, name: String, discount: Double, description: String, disabled: Bool) {
        self.id = id
        self.partitionKey = partitionKey
        self.rowid = rowid
        self.createdDate = createdDate
        self.createdBy = createdBy
        self.name = name
        self.discount = discount
        self.description = description
        self.disabled = disabled
    }
}
